import mongoose from "mongoose"

const userSchema = new mongoose.Schema(
  {
    name: String,
    email: {
      type: String,
      unique: true,
      required: [true, "Email is required"],
      match: [/^\S+@\S+\.\S+$/, "Please use a valid email address"],
    },
    password: String,
    image: String,
    emailVerified: Date,
  },
  { timestamps: true },
)

// Check if the model is already defined to prevent overwriting during hot reloads
const User = mongoose.models.User || mongoose.model("User", userSchema)

export default User
