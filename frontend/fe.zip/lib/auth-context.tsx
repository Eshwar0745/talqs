"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type User = {
  id: string
  email: string
  fullName: string
  isAdmin: boolean
}

type AuthContextType = {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  signup: (email: string, fullName: string, password: string) => Promise<boolean>
  logout: () => void
  getAllUsers: () => User[]
  deleteUser: (id: string) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Admin credentials
const ADMIN_EMAIL = "admin@talqs.com"
const ADMIN_PASSWORD = "admin123"

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    // Check if user is logged in on mount
    const storedUser = localStorage.getItem("talqs_user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    // Admin login
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      const adminUser = {
        id: "admin-1",
        email: ADMIN_EMAIL,
        fullName: "Admin User",
        isAdmin: true,
      }
      setUser(adminUser)
      localStorage.setItem("talqs_user", JSON.stringify(adminUser))
      return true
    }

    // Regular user login
    const users = JSON.parse(localStorage.getItem("talqs_users") || "[]")
    const foundUser = users.find((u: any) => u.email === email)

    if (foundUser && foundUser.password === password) {
      const { password, ...userWithoutPassword } = foundUser
      setUser(userWithoutPassword)
      localStorage.setItem("talqs_user", JSON.stringify(userWithoutPassword))
      return true
    }

    return false
  }

  const signup = async (email: string, fullName: string, password: string): Promise<boolean> => {
    // Check if email already exists
    const users = JSON.parse(localStorage.getItem("talqs_users") || "[]")
    if (users.some((u: any) => u.email === email)) {
      return false
    }

    // Create new user
    const newUser = {
      id: `user-${Date.now()}`,
      email,
      fullName,
      password,
      isAdmin: false,
    }

    // Save to localStorage
    users.push(newUser)
    localStorage.setItem("talqs_users", JSON.stringify(users))

    // Log in the new user
    const { password: _, ...userWithoutPassword } = newUser
    setUser(userWithoutPassword)
    localStorage.setItem("talqs_user", JSON.stringify(userWithoutPassword))

    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("talqs_user")
  }

  const getAllUsers = (): User[] => {
    const users = JSON.parse(localStorage.getItem("talqs_users") || "[]")
    return users.map((u: any) => {
      const { password, ...userWithoutPassword } = u
      return userWithoutPassword
    })
  }

  const deleteUser = (id: string) => {
    const users = JSON.parse(localStorage.getItem("talqs_users") || "[]")
    const updatedUsers = users.filter((u: any) => u.id !== id)
    localStorage.setItem("talqs_users", JSON.stringify(updatedUsers))
  }

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, getAllUsers, deleteUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
