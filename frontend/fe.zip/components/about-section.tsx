"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Scale, Gavel, FileText, BookOpen } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const isInView = useInView(sectionRef, { once: true, amount: 0.3 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  }

  return (
    <motion.section
      ref={sectionRef}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={containerVariants}
      id="about"
      className="py-20 relative"
    >
      <div className="absolute inset-0 gradient-bg-subtle rounded-3xl -z-10"></div>

      {/* Animated background elements */}
      <div className="absolute top-20 left-20 w-64 h-64 blur-circle opacity-30"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 blur-circle opacity-30"></div>

      <div className="text-center mb-16">
        <motion.p variants={itemVariants} className="text-sm font-medium text-primary mb-2">
          ABOUT US
        </motion.p>
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-4">
          About TALQS
        </motion.h2>
        <motion.p variants={itemVariants} className="text-muted-foreground max-w-2xl mx-auto">
          Learn more about our AI-powered legal assistant platform and the technology behind it.
        </motion.p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto px-4">
        <motion.div variants={itemVariants}>
          <Card className="h-full premium-card">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-muted-foreground mb-6">
                TALQS was founded with a clear mission: to make legal document analysis accessible, efficient, and
                insightful for legal professionals. We believe that AI should augment human expertise, not replace it.
              </p>
              <p className="text-muted-foreground">
                By combining cutting-edge transformer-based architecture with legal domain expertise, we've created a
                platform that understands the nuances of legal language and can provide valuable insights that save time
                and improve outcomes.
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="h-full premium-card">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-4">The Technology</h3>
              <p className="text-muted-foreground mb-6">
                At the core of TALQS is our proprietary transformer-based architecture specifically trained on millions
                of legal documents, judgments, and precedents from multiple jurisdictions.
              </p>
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Scale className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Legal Precision</h4>
                    <p className="text-sm text-muted-foreground">Domain-specific training</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Gavel className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Case Analysis</h4>
                    <p className="text-sm text-muted-foreground">Precedent recognition</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Document Processing</h4>
                    <p className="text-sm text-muted-foreground">Advanced OCR capabilities</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-primary/10 p-2 rounded-full">
                    <BookOpen className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium">Knowledge Base</h4>
                    <p className="text-sm text-muted-foreground">Extensive legal corpus</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="md:col-span-2">
          <Card className="premium-card">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-4">Our Team</h3>
              <p className="text-muted-foreground mb-6">
                TALQS was developed by a diverse team of legal professionals, AI researchers, and software engineers who
                share a passion for legal technology and innovation. Our team combines decades of experience in both
                legal practice and artificial intelligence.
              </p>
              <div className="grid md:grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <div className="w-24 h-24 rounded-full bg-primary/10 mx-auto mb-4"></div>
                  <h4 className="font-semibold">Dr. Sarah Chen</h4>
                  <p className="text-sm text-muted-foreground">Chief AI Officer</p>
                </div>
                <div className="text-center">
                  <div className="w-24 h-24 rounded-full bg-primary/10 mx-auto mb-4"></div>
                  <h4 className="font-semibold">Michael Rodriguez, J.D.</h4>
                  <p className="text-sm text-muted-foreground">Legal Director</p>
                </div>
                <div className="text-center">
                  <div className="w-24 h-24 rounded-full bg-primary/10 mx-auto mb-4"></div>
                  <h4 className="font-semibold">Alex Thompson</h4>
                  <p className="text-sm text-muted-foreground">CTO</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.section>
  )
}
