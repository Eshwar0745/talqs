// Simplified toaster component
export function Toaster() {
  // In a real app, this would render actual toast notifications
  return null
}
