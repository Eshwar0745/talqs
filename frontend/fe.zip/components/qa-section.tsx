"use client"

import { useState, useEffect, useRef } from "react"
import type React from "react"
import { motion, useInView } from "framer-motion"
import { Send, Play, Pause, AlertCircle, MessageSquare, Sparkles, Bot, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"

export default function QASection() {
  const [question, setQuestion] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [answer, setAnswer] = useState("")
  const [isPlaying, setIsPlaying] = useState(false)
  const [displayedAnswer, setDisplayedAnswer] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [chatHistory, setChatHistory] = useState<{ type: "user" | "ai"; content: string }[]>([])

  const sectionRef = useRef<HTMLElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(sectionRef, { once: true, amount: 0.3 })
  const typingRef = useRef<NodeJS.Timeout | null>(null)

  const fullAnswer =
    "Based on the uploaded judgment, the court ruled in favor of the plaintiff. The key legal principle applied was 'reasonable care' under tort law. The defendant failed to demonstrate adequate precautions, which constituted negligence according to the precedent set in Smith v. Jones (2018)."

  useEffect(() => {
    return () => {
      if (typingRef.current) clearTimeout(typingRef.current)
    }
  }, [])

  useEffect(() => {
    // Scroll to bottom of chat when new messages are added
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [chatHistory])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!question.trim()) return

    // Add user question to chat history
    setChatHistory([...chatHistory, { type: "user", content: question }])

    setIsProcessing(true)
    setProgress(0)
    setAnswer("")
    setDisplayedAnswer("")

    // Simulate AI processing
    let currentProgress = 0
    const interval = setInterval(() => {
      currentProgress += 5
      setProgress(currentProgress)

      if (currentProgress >= 100) {
        clearInterval(interval)
        setIsProcessing(false)
        setAnswer(fullAnswer)
        simulateTyping()
        setQuestion("") // Clear input after sending
      }
    }, 100)
  }

  const simulateTyping = () => {
    setIsTyping(true)

    // Add empty AI message to show typing indicator
    setChatHistory((prev) => [...prev, { type: "ai", content: "" }])

    let i = 0
    const typing = () => {
      if (i < fullAnswer.length) {
        setDisplayedAnswer(fullAnswer.substring(0, i + 1))
        i++
        typingRef.current = setTimeout(typing, 20)
      } else {
        setIsTyping(false)
        // Update the AI message with full content
        setChatHistory((prev) => {
          const newHistory = [...prev]
          newHistory[newHistory.length - 1].content = fullAnswer
          return newHistory
        })
      }
    }
    typing()
  }

  const toggleAudio = () => {
    setIsPlaying(!isPlaying)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  }

  return (
    <motion.section
      ref={sectionRef}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={containerVariants}
      id="qa"
      className="py-20"
    >
      <div className="text-center mb-16">
        <motion.p variants={itemVariants} className="text-sm font-medium text-primary mb-2">
          LEGAL Q&A
        </motion.p>
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-4">
          Ask Legal Questions
        </motion.h2>
        <motion.p variants={itemVariants} className="text-muted-foreground max-w-2xl mx-auto">
          Ask specific questions about your legal documents and get AI-powered answers.
        </motion.p>
      </div>

      <motion.div variants={itemVariants}>
        <Card className="max-w-3xl mx-auto premium-card glow-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Legal Assistant
              </CardTitle>
              <HoverCard>
                <HoverCardTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <AlertCircle className="h-5 w-5" />
                  </Button>
                </HoverCardTrigger>
                <HoverCardContent className="w-80 glass shadow-glow-sm">
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold">Q&A Section</h4>
                    <p className="text-sm">
                      Ask specific questions about your uploaded legal documents. For example: "What was the court's
                      ruling?" or "What legal principles were applied?"
                    </p>
                  </div>
                </HoverCardContent>
              </HoverCard>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              {/* Chat messages area */}
              <div className="bg-muted/30 backdrop-blur-sm rounded-lg p-4 h-80 overflow-y-auto">
                {chatHistory.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                    <motion.div
                      animate={{
                        scale: [1, 1.1, 1],
                        opacity: [0.5, 0.8, 0.5],
                      }}
                      transition={{
                        repeat: Number.POSITIVE_INFINITY,
                        duration: 3,
                      }}
                      className="mb-4 ai-avatar"
                    >
                      <Bot className="h-12 w-12 text-primary" />
                    </motion.div>
                    <p>Ask a question to start the conversation</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {chatHistory.map((message, index) => (
                      <div key={index} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
                        {message.type === "ai" && (
                          <div className="ai-avatar mr-2 self-end">
                            <Bot className="h-5 w-5 text-primary" />
                          </div>
                        )}
                        <div
                          className={`chat-bubble ${message.type === "user" ? "chat-bubble-user" : "chat-bubble-ai"}`}
                        >
                          {message.content ? (
                            <p>{message.content}</p>
                          ) : (
                            <div className="typing-indicator">
                              <span></span>
                              <span></span>
                              <span></span>
                            </div>
                          )}

                          {message.type === "ai" && message.content && (
                            <div className="mt-2 flex justify-between items-center">
                              <Badge variant="outline" className="gap-1 bg-primary/10 backdrop-blur-sm">
                                <Sparkles className="h-3 w-3 text-primary" />
                                AI Generated
                              </Badge>
                              <button onClick={toggleAudio} className={`tts-button ${isPlaying ? "active" : ""}`}>
                                {isPlaying ? (
                                  <Pause className="h-4 w-4 text-primary" />
                                ) : (
                                  <Play className="h-4 w-4 text-primary" />
                                )}
                              </button>
                            </div>
                          )}
                        </div>
                        {message.type === "user" && (
                          <div className="user-avatar ml-2 self-end">
                            <User className="h-5 w-5 text-accent" />
                          </div>
                        )}
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                )}
              </div>

              {/* Processing indicator */}
              {isProcessing && (
                <motion.div
                  className="space-y-2"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex justify-between text-sm">
                    <span>Processing question...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </motion.div>
              )}

              {/* Input area */}
              <form onSubmit={handleSubmit} className="relative">
                <Input
                  placeholder="Type your legal question here..."
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  className="pr-12 bg-background/50 backdrop-blur-sm"
                  disabled={isProcessing}
                />
                <Button
                  type="submit"
                  size="icon"
                  className="absolute right-1 top-1 h-8 w-8 rounded-full"
                  disabled={!question.trim() || isProcessing}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>

              {/* Example questions */}
              <div className="text-sm text-muted-foreground">
                <p>Example questions:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-1">
                  <motion.button
                    whileHover={{ x: 5, backgroundColor: "rgba(var(--primary-rgb), 0.1)" }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    className="text-left p-2 rounded-md hover:text-foreground"
                    onClick={() => setQuestion("What was the court's ruling in this case?")}
                  >
                    What was the court's ruling in this case?
                  </motion.button>
                  <motion.button
                    whileHover={{ x: 5, backgroundColor: "rgba(var(--primary-rgb), 0.1)" }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    className="text-left p-2 rounded-md hover:text-foreground"
                    onClick={() => setQuestion("What legal principles were applied?")}
                  >
                    What legal principles were applied?
                  </motion.button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.section>
  )
}
