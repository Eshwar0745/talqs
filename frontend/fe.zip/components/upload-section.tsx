"use client"

import type React from "react"
import { useState, useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Upload, FileText, Check, AlertCircle, FileUp, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"

export default function UploadSection() {
  const [isDragging, setIsDragging] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)
  const isInView = useInView(sectionRef, { once: true, amount: 0.3 })

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0])
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileUpload(e.target.files[0])
    }
  }

  const handleFileUpload = (file: File) => {
    setUploadedFile(file)
    setIsUploading(true)
    setUploadSuccess(false)

    // Simulate upload progress
    let progress = 0
    const interval = setInterval(() => {
      progress += 5
      setUploadProgress(progress)

      if (progress >= 100) {
        clearInterval(interval)
        setIsUploading(false)
        setUploadSuccess(true)
      }
    }, 200)
  }

  const removeFile = () => {
    setUploadedFile(null)
    setUploadSuccess(false)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  }

  return (
    <motion.section
      ref={sectionRef}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      variants={containerVariants}
      id="upload"
      className="py-20 relative"
    >
      <div className="absolute inset-0 gradient-bg-subtle rounded-3xl -z-10"></div>

      <div className="text-center mb-16">
        <motion.p variants={itemVariants} className="text-sm font-medium text-primary mb-2">
          DOCUMENT UPLOAD
        </motion.p>
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-4">
          Upload Legal Documents
        </motion.h2>
        <motion.p variants={itemVariants} className="text-muted-foreground max-w-2xl mx-auto">
          Upload your legal judgment files to analyze, summarize, and ask questions about them.
        </motion.p>
      </div>

      <motion.div variants={itemVariants}>
        <Card className="max-w-3xl mx-auto premium-card glow-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileUp className="h-5 w-5 text-primary" />
                Document Upload
              </CardTitle>
              <HoverCard>
                <HoverCardTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <AlertCircle className="h-5 w-5" />
                  </Button>
                </HoverCardTrigger>
                <HoverCardContent className="w-80 glass shadow-glow-sm">
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold">Upload Section</h4>
                    <p className="text-sm">
                      Drag and drop your legal documents here or click to browse. We support PDF, DOCX, and TXT files up
                      to 50MB.
                    </p>
                  </div>
                </HoverCardContent>
              </HoverCard>
            </div>
            <CardDescription>Drag and drop your files or click to browse</CardDescription>
          </CardHeader>
          <CardContent>
            <motion.div
              whileHover={{ scale: isDragging ? 1 : 1.01 }}
              whileTap={{ scale: 0.99 }}
              className={`upload-dropzone ${isDragging ? "upload-dropzone-active" : "upload-dropzone-inactive"}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <input
                type="file"
                id="file-upload"
                className="hidden"
                accept=".pdf,.docx,.txt"
                onChange={handleFileChange}
              />
              <label htmlFor="file-upload" className="flex flex-col items-center cursor-pointer">
                <motion.div
                  animate={
                    isDragging
                      ? {
                          y: [0, -10, 0],
                          scale: [1, 1.1, 1],
                        }
                      : {}
                  }
                  transition={{ duration: 0.5, repeat: isDragging ? Number.POSITIVE_INFINITY : 0 }}
                  className="bg-primary/10 p-4 rounded-full mb-4 glow-primary"
                >
                  <Upload className="h-12 w-12 text-primary" />
                </motion.div>
                <p className="text-lg font-medium mb-2">
                  {isDragging ? "Drop your files here" : "Drag your files here or click to browse"}
                </p>
                <p className="text-sm text-muted-foreground">Supports PDF, DOCX, and TXT files (max 50MB)</p>
              </label>
            </motion.div>

            {isUploading && (
              <motion.div
                className="mt-6 space-y-2"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex justify-between text-sm">
                  <span>Uploading...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </motion.div>
            )}

            {uploadedFile && !isUploading && (
              <motion.div
                className="mt-6 flex items-center p-4 bg-muted/50 backdrop-blur-sm rounded-lg"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mr-4">
                  {uploadSuccess ? (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 200, damping: 10 }}
                      className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center"
                    >
                      <Check className="h-6 w-6 text-green-500" />
                    </motion.div>
                  ) : (
                    <FileText className="h-8 w-8 text-primary" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{uploadedFile.name}</p>
                  <p className="text-sm text-muted-foreground">{(uploadedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full hover:bg-destructive/10"
                  onClick={removeFile}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </motion.div>
            )}
          </CardContent>
          <CardFooter>
            <Button className="w-full btn-premium glow-primary" disabled={isUploading || !uploadedFile}>
              {isUploading ? "Uploading..." : uploadedFile ? "Analyze Document" : "Upload a Document"}
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </motion.section>
  )
}
