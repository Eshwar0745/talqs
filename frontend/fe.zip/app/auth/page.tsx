"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useSearchParams, useRouter } from "next/navigation"
import { Scale, Gavel, FileText, Eye, EyeOff, Github, Mail } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

export default function AuthPage() {
  const searchParams = useSearchParams()
  const tabParam = searchParams.get("tab")
  const [activeTab, setActiveTab] = useState(tabParam === "signup" ? "signup" : "login")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const router = useRouter()
  const { login, signup, user } = useAuth()

  // Form states
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (tabParam === "signup") {
      setActiveTab("signup")
    } else if (tabParam === "login") {
      setActiveTab("login")
    }
  }, [tabParam])

  useEffect(() => {
    // Redirect if already logged in
    if (user) {
      router.push("/")
    }
  }, [user, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)

    try {
      if (activeTab === "signup") {
        // Validate form
        if (password !== confirmPassword) {
          setError("Passwords do not match")
          setIsSubmitting(false)
          return
        }

        if (password.length < 6) {
          setError("Password must be at least 6 characters")
          setIsSubmitting(false)
          return
        }

        // Sign up
        const success = await signup(email, fullName, password)
        if (success) {
          toast({
            title: "Account created!",
            description: "You have successfully signed up.",
          })
          router.push("/")
        } else {
          setError("Email already exists")
        }
      } else {
        // Login
        const success = await login(email, password)
        if (success) {
          toast({
            title: "Welcome back!",
            description: "You have successfully logged in.",
          })
          router.push("/")
        } else {
          setError("Invalid email or password")
        }
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error(err)
    }

    setIsSubmitting(false)
  }

  return (
    <div className="auth-container">
      <Toaster />
      {/* Left side - Illustration */}
      <div className="auth-illustration">
        <div className="relative h-full w-full flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-white text-center z-10"
          >
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center">
                  <Scale className="h-10 w-10 text-white" />
                </div>
                <motion.div
                  animate={{
                    y: [0, -10, 0],
                  }}
                  transition={{
                    repeat: Number.POSITIVE_INFINITY,
                    duration: 3,
                    ease: "easeInOut",
                  }}
                  className="absolute -top-4 -right-4 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center"
                >
                  <Gavel className="h-5 w-5 text-white" />
                </motion.div>
                <motion.div
                  animate={{
                    y: [0, 10, 0],
                  }}
                  transition={{
                    repeat: Number.POSITIVE_INFINITY,
                    duration: 4,
                    ease: "easeInOut",
                  }}
                  className="absolute -bottom-2 -left-2 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"
                >
                  <FileText className="h-4 w-4 text-white" />
                </motion.div>
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">TALQS</h1>
            <p className="max-w-md mx-auto text-white/80">
              AI-powered legal document analysis and question answering platform for legal professionals
            </p>
          </motion.div>

          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden">
            <motion.div
              animate={{
                rotate: [0, 360],
              }}
              transition={{
                repeat: Number.POSITIVE_INFINITY,
                duration: 30,
                ease: "linear",
              }}
              className="absolute top-1/4 left-1/4 w-full h-full bg-white/5 rounded-full blur-3xl"
              style={{ width: "60%", height: "60%" }}
            />
            <motion.div
              animate={{
                rotate: [360, 0],
              }}
              transition={{
                repeat: Number.POSITIVE_INFINITY,
                duration: 20,
                ease: "linear",
              }}
              className="absolute bottom-1/4 right-1/4 w-full h-full bg-white/5 rounded-full blur-3xl"
              style={{ width: "50%", height: "50%" }}
            />
          </div>
        </div>
      </div>

      {/* Right side - Auth form */}
      <div className="flex items-center justify-center p-6 md:p-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="text-center mb-8">
            <Link href="/" className="inline-flex items-center gap-2 mb-6">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Scale className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-bold gradient-text">TALQS</span>
            </Link>
            <h2 className="text-2xl font-bold mb-2">
              {activeTab === "login" ? "Welcome back" : "Create your account"}
            </h2>
            <p className="text-muted-foreground">
              {activeTab === "login"
                ? "Enter your email to sign in to your account"
                : "Enter your information to create an account"}
            </p>
          </div>

          {/* Tab switcher */}
          <div className="flex rounded-lg bg-muted p-1 mb-6">
            <button
              className={`flex-1 py-2 px-4 rounded-md transition-all ${
                activeTab === "login" ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("login")}
            >
              Login
            </button>
            <button
              className={`flex-1 py-2 px-4 rounded-md transition-all ${
                activeTab === "signup" ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("signup")}
            >
              Sign up
            </button>
          </div>

          {/* Error message */}
          {error && <div className="bg-destructive/10 text-destructive p-3 rounded-md mb-4 text-sm">{error}</div>}

          {/* Auth form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {activeTab === "signup" && (
              <div>
                <label htmlFor="fullName" className="form-label">
                  Full Name
                </label>
                <input
                  id="fullName"
                  type="text"
                  className="form-input"
                  placeholder="John Doe"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required={activeTab === "signup"}
                />
              </div>
            )}

            <div>
              <label htmlFor="email" className="form-label">
                Email
              </label>
              <input
                id="email"
                type="email"
                className="form-input"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  className="form-input pr-10"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {activeTab === "signup" && (
              <div>
                <label htmlFor="confirmPassword" className="form-label">
                  Confirm Password
                </label>
                <div className="relative">
                  <input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    className="form-input pr-10"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required={activeTab === "signup"}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>
            )}

            {activeTab === "login" && (
              <div className="flex justify-end">
                <Link href="/auth/forgot-password" className="text-sm text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
            )}

            <Button type="submit" className="w-full btn-premium glow-primary" disabled={isSubmitting}>
              {isSubmitting ? (
                <span className="flex items-center">
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  {activeTab === "login" ? "Signing in..." : "Creating account..."}
                </span>
              ) : activeTab === "login" ? (
                "Sign in"
              ) : (
                "Create account"
              )}
            </Button>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button type="button" className="social-login-btn">
                <Github className="h-4 w-4" />
                <span>GitHub</span>
              </button>
              <button type="button" className="social-login-btn">
                <Mail className="h-4 w-4" />
                <span>Google</span>
              </button>
            </div>

            <p className="text-center text-sm text-muted-foreground mt-6">
              {activeTab === "login" ? (
                <>
                  Don't have an account?{" "}
                  <button type="button" className="text-primary hover:underline" onClick={() => setActiveTab("signup")}>
                    Sign up
                  </button>
                </>
              ) : (
                <>
                  Already have an account?{" "}
                  <button type="button" className="text-primary hover:underline" onClick={() => setActiveTab("login")}>
                    Sign in
                  </button>
                </>
              )}
            </p>
          </form>
        </motion.div>
      </div>
    </div>
  )
}
